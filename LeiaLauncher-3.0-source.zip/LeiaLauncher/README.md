# Leia Launcher 3.0

Tablet-first Android launcher with an iPadOS-inspired home screen, responsive app grid, widget-style information cards, Yandex search, favorites Dock, category filters, and light/dark themes.

Target device: DOOGEE T30Pro / Android 13.

Build: `gradle assembleDebug`
