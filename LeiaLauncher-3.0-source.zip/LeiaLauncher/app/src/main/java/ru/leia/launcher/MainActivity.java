package ru.leia.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.ResolveInfo;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private boolean dark;
    private String filter = "Все";
    private int bg, surface, surface2, fg, muted, accent;
    private LinearLayout root, content;
    private List<ResolveInfo> apps;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("leia", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", isSystemDark());
        applyPalette(); buildHome();
    }
    private boolean isSystemDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }
    private void applyPalette() {
        if (dark) {
            bg=Color.rgb(12,18,31); surface=Color.rgb(29,39,57); surface2=Color.rgb(39,52,73);
            fg=Color.rgb(246,248,252); muted=Color.rgb(169,184,204); accent=Color.rgb(128,198,255);
        } else {
            bg=Color.rgb(225,233,244); surface=Color.rgb(246,249,253); surface2=Color.rgb(235,242,250);
            fg=Color.rgb(28,43,64); muted=Color.rgb(102,119,141); accent=Color.rgb(40,125,205);
        }
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, float size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}

    private void buildHome() {
        root=col(); root.setBackgroundColor(bg); root.setPadding(dp(22),dp(12),dp(22),dp(10));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        content=col(); scroll.addView(content);

        LinearLayout status=row();
        TextView date=label(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),13,muted,true);
        status.addView(date,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=label("⚙",22,fg,false); settings.setGravity(Gravity.CENTER);
        settings.setBackground(shape(surface,18,0)); status.addView(settings,lp(44,44));
        settings.setOnClickListener(v->showSettings()); content.addView(status,lp(-1,48));

        LinearLayout hero=row(); hero.setGravity(Gravity.CENTER_VERTICAL); hero.setPadding(dp(20),dp(14),dp(20),dp(14));
        hero.setBackground(shape(surface,26,0));
        LinearLayout time=col();
        TextView clock=label(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),48,fg,true);
        time.addView(clock); time.addView(label("ТВОЁ ПРОСТРАНСТВО",10,accent,true));
        hero.addView(time,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=col(); right.setGravity(Gravity.END);
        TextView day=label(new SimpleDateFormat("d",Locale.getDefault()).format(new Date()),34,fg,true); day.setGravity(Gravity.RIGHT);
        right.addView(day); right.addView(label(new SimpleDateFormat("MMM",Locale.getDefault()).format(new Date()).toUpperCase(new Locale("ru")),12,muted,true));
        hero.addView(right); LinearLayout.LayoutParams hp=lp(-1,112);hp.topMargin=dp(12);content.addView(hero,hp);

        LinearLayout widgets=row(); widgets.setGravity(Gravity.TOP); widgets.setWeightSum(2);
        LinearLayout weather=widgetCard("ПОГОДА","Добавить город","☀",1);
        LinearLayout music=widgetCard("СЕЙЧАС ИГРАЕТ","Открой любимую музыку","♫",1);
        LinearLayout.LayoutParams w1=new LinearLayout.LayoutParams(0,dp(104),1);w1.rightMargin=dp(8);
        LinearLayout.LayoutParams w2=new LinearLayout.LayoutParams(0,dp(104),1);w2.leftMargin=dp(8);
        widgets.addView(weather,w1);widgets.addView(music,w2);
        LinearLayout.LayoutParams wlp=lp(-1,104);wlp.topMargin=dp(12);content.addView(widgets,wlp);

        LinearLayout searchBox=row(); searchBox.setPadding(dp(15),0,dp(14),0); searchBox.setBackground(shape(surface,18,0));
        TextView glass=label("⌕",24,muted,false);searchBox.addView(glass);
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(fg);search.setHintTextColor(muted);
        search.setHint("Поиск в Яндексе или приложениях");search.setTextSize(14);search.setPadding(dp(8),0,0,0);
        search.setBackgroundColor(Color.TRANSPARENT);search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())searchYandex(q);return true;});
        searchBox.addView(search,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams slp=lp(-1,52);slp.topMargin=dp(14);content.addView(searchBox,slp);

        LinearLayout section=row(); TextView title=label("Приложения",21,fg,true);
        section.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=label("Все  ›",13,accent,true);all.setOnClickListener(v->{filter="Все";buildHome();});section.addView(all);
        LinearLayout.LayoutParams secp=lp(-1,48);secp.topMargin=dp(12);content.addView(section,secp);

        LinearLayout tabs=row();String[] filters={"Все","Избранное","Кино","Игры","Радио","Работа"};
        for(String f:filters){TextView chip=label(f,12,filter.equals(f)?(dark?Color.rgb(15,31,49):Color.WHITE):muted,true);
            chip.setGravity(Gravity.CENTER);chip.setPadding(dp(13),dp(8),dp(13),dp(8));chip.setBackground(shape(filter.equals(f)?accent:surface,18,0));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(34));cp.rightMargin=dp(7);tabs.addView(chip,cp);chip.setOnClickListener(v->{filter=f;buildHome();});}
        ScrollView tabScroll=new ScrollView(this);tabScroll.setHorizontalScrollBarEnabled(false);tabScroll.setFillViewport(false);tabScroll.addView(tabs);
        content.addView(tabScroll,lp(-1,38));

        apps=getLaunchableApps();Set<String> favorites=prefs.getStringSet("favorites",new HashSet<>());List<ResolveInfo> shown=new ArrayList<>();
        for(ResolveInfo ri:apps){String pkg=ri.activityInfo.packageName;
            if(filter.equals("Избранное")&&!favorites.contains(pkg))continue;
            if(!filter.equals("Все")&&!filter.equals("Избранное")&&!belongs(ri,filter))continue;shown.add(ri);}
        if(shown.isEmpty()){TextView empty=label("Пока пусто. Добавь приложения в избранное долгим нажатием.",13,muted,false);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(24),0,dp(24));content.addView(empty);}
        GridLayout grid=new GridLayout(this);int cols=getResources().getConfiguration().orientation==2?7:5;grid.setColumnCount(cols);
        for(ResolveInfo ri:shown){LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(2),dp(8),dp(2),dp(4));
            ImageView icon=new ImageView(this);try{icon.setImageDrawable(ri.loadIcon(getPackageManager()));}catch(Exception ignored){}
            tile.addView(icon,lp(52,52));TextView name=label(ri.loadLabel(getPackageManager()).toString(),11,fg,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);tile.addView(name,lp(-1,34));
            tile.setOnClickListener(v->launch(ri));tile.setOnLongClickListener(v->{toggleFavorite(ri);return true;});
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(100);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(3),dp(2),dp(3),dp(2));grid.addView(tile,gp);}
        content.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));buildDock(root,favorites);setContentView(root);
    }
    private LinearLayout widgetCard(String heading,String body,String glyph,int weight){
        LinearLayout card=col();card.setPadding(dp(14),dp(12),dp(12),dp(10));card.setBackground(shape(surface2,22,0));
        LinearLayout top=row();top.addView(label(heading,9,accent,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(label(glyph,21,accent,true));card.addView(top);
        TextView b=label(body,12,fg,false);b.setMaxLines(2);LinearLayout.LayoutParams bp=lp(-1,-2);bp.topMargin=dp(12);card.addView(b,bp);return card;
    }
    private boolean belongs(ResolveInfo r,String category){String s=(r.loadLabel(getPackageManager()).toString()+" "+r.activityInfo.packageName).toLowerCase(Locale.ROOT);
        if(category.equals("Кино"))return has(s,"video","kino","ivi","okko","film","media","youtube","kinopoisk","плеер");
        if(category.equals("Игры"))return has(s,"game","games","playstation","xbox","steam","игр");
        if(category.equals("Радио"))return has(s,"radio","malahit","sdr","радио");
        return has(s,"office","work","docs","word","excel","mail","calendar","банк","госуслуг");}
    private boolean has(String s,String...keys){for(String k:keys)if(s.contains(k))return true;return false;}
    private void buildDock(LinearLayout parent,Set<String> favorites){
        LinearLayout dock=row();dock.setGravity(Gravity.CENTER);dock.setPadding(dp(10),dp(8),dp(10),dp(8));dock.setBackground(shape(surface,24,0));int count=0;
        for(ResolveInfo ri:apps){if(favorites.contains(ri.activityInfo.packageName)&&count<6){ImageView icon=new ImageView(this);try{icon.setImageDrawable(ri.loadIcon(getPackageManager()));}catch(Exception ignored){}
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(46),dp(46));ip.setMargins(dp(7),0,dp(7),0);dock.addView(icon,ip);icon.setOnClickListener(v->launch(ri));count++;}}
        if(count==0){TextView hint=label("Избранное · удерживай иконку, чтобы добавить",11,muted,false);hint.setGravity(Gravity.CENTER);dock.addView(hint);}
        LinearLayout.LayoutParams dpLp=lp(-1,62);dpLp.topMargin=dp(8);parent.addView(dock,dpLp);
    }
    private void toggleFavorite(ResolveInfo ri){Set<String> set=new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));String pkg=ri.activityInfo.packageName;
        if(set.contains(pkg)){set.remove(pkg);Toast.makeText(this,"Удалено из избранного",Toast.LENGTH_SHORT).show();}else{set.add(pkg);Toast.makeText(this,"Добавлено в Dock",Toast.LENGTH_SHORT).show();}
        prefs.edit().putStringSet("favorites",set).apply();buildHome();}
    private void showSettings(){String[] choices={"Автоматически (как в Android)","Тёмная тема","Светлая тема","Сбросить избранное"};
        new AlertDialog.Builder(this).setTitle("Настройки Leia").setItems(choices,(d,w)->{if(w==0){dark=isSystemDark();prefs.edit().remove("dark").apply();}if(w==1||w==2){dark=w==1;prefs.edit().putBoolean("dark",dark).apply();}if(w==3){prefs.edit().remove("favorites").apply();}applyPalette();buildHome();}).setNegativeButton("Закрыть",null).show();}
    private List<ResolveInfo> getLaunchableApps(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=getPackageManager().queryIntentActivities(i,0);
        Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));return list;}
    private void launch(ResolveInfo r){try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setClassName(r.activityInfo.packageName,r.activityInfo.name);startActivity(i);}catch(Exception e){Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show();}}
    private void searchYandex(String q){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://yandex.ru/search/?text="+Uri.encode(q==null?"":q.trim()))));}catch(Exception e){Toast.makeText(this,"Не найден браузер",Toast.LENGTH_LONG).show();}}
}
