package ru.leia.launcher;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int white = Color.rgb(245,247,252);
    private final int muted = Color.rgb(184,197,218);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12,22,43));
        getWindow().setNavigationBarColor(Color.rgb(7,14,29));
        buildHome();
    }

    private GradientDrawable panel(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{color, Color.rgb(23,43,76)});
        d.setCornerRadius(dp(22)); d.setStroke(dp(1), stroke); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void buildHome() {
        root = column(); root.setPadding(dp(18),dp(12),dp(18),dp(10));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(9,19,40),Color.rgb(25,54,91),Color.rgb(8,17,35)}));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = column(); scroll.addView(content);

        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView clock = text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()), 34, white, true);
        header.addView(clock, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(text(new SimpleDateFormat("EEE, d MMM",new Locale("ru")).format(new Date()), 15, muted, false));
        content.addView(header, lp(-1,54));

        LinearLayout search = row(); search.setPadding(dp(18),0,dp(14),0); search.setBackground(panel(Color.rgb(45,58,81),0x557EA4D8));
        EditText input = new EditText(this); input.setSingleLine(true); input.setTextColor(white); input.setHintTextColor(muted);
        input.setHint("Поиск в Яндексе"); input.setTextSize(17); input.setBackgroundColor(Color.TRANSPARENT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setOnEditorActionListener((v, action, event) -> { searchYandex(input.getText().toString()); return true; });
        search.addView(input,new LinearLayout.LayoutParams(0,dp(54),1));
        TextView go = text("⌕",30,white,true); go.setGravity(Gravity.CENTER); go.setOnClickListener(v -> searchYandex(input.getText().toString()));
        search.addView(go,lp(42,54)); content.addView(search,lp(-1,58));

        LinearLayout cards = row(); cards.setGravity(Gravity.CENTER_VERTICAL); cards.setPadding(0,dp(16),0,dp(12));
        LinearLayout timeCard = column(); timeCard.setPadding(dp(16),dp(14),dp(12),dp(14)); timeCard.setBackground(panel(0xCC172A4B,0x667DA9D9));
        timeCard.addView(text("Добро пожаловать",14,muted,false)); timeCard.addView(text("Твой цифровой дом",21,white,true));
        timeCard.addView(text("Leia Launcher · версия 0.1",12,muted,false));
        cards.addView(timeCard,new LinearLayout.LayoutParams(0,dp(112),1));
        LinearLayout weather = column(); weather.setGravity(Gravity.CENTER); weather.setPadding(dp(10),dp(10),dp(10),dp(10)); weather.setBackground(panel(0xCC172A4B,0x667DA9D9));
        TextView weatherTitle=text("☼",30,0xFFFFD36B,true); weatherTitle.setGravity(Gravity.CENTER); weather.addView(weatherTitle);
        weather.addView(text("Погода",14,white,true)); weather.addView(text("Добавим виджет",10,muted,false));
        LinearLayout.LayoutParams wp=lp(126,112); wp.leftMargin=dp(10); cards.addView(weather,wp); content.addView(cards);

        LinearLayout section=row(); section.addView(text("Приложения",21,white,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=text("Обновить",13,0xFF7ED8FF,true); refresh.setOnClickListener(v -> buildHome()); section.addView(refresh); content.addView(section,lp(-1,42));

        GridLayout grid = new GridLayout(this); grid.setColumnCount(getResources().getConfiguration().orientation==2 ? 6 : 4);
        List<ResolveInfo> apps = getLaunchableApps();
        for (ResolveInfo ri : apps) {
            LinearLayout tile=column(); tile.setGravity(Gravity.CENTER); tile.setPadding(dp(4),dp(9),dp(4),dp(8));
            ImageView icon=new ImageView(this); try { icon.setImageDrawable(ri.loadIcon(getPackageManager())); } catch(Exception ignored) {}
            tile.addView(icon,lp(48,48)); TextView name=text(ri.loadLabel(getPackageManager()).toString(),11,white,false);
            name.setGravity(Gravity.CENTER); name.setMaxLines(2); tile.addView(name,lp(-1,34));
            tile.setOnClickListener(v -> launch(ri));
            tile.setOnLongClickListener(v -> { Toast.makeText(this,ri.loadLabel(getPackageManager()),Toast.LENGTH_SHORT).show(); return true; });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=dp(94); p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); p.setMargins(dp(2),dp(2),dp(2),dp(2)); grid.addView(tile,p);
        }
        content.addView(grid);
        TextView footer=text("Leia Launcher  •  Долгое нажатие на приложение пока показывает его название",11,muted,false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(16),0,dp(18)); content.addView(footer);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private List<ResolveInfo> getLaunchableApps() {
        Intent intent=new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list=getPackageManager().queryIntentActivities(intent,0);
        Collections.sort(list,new Comparator<ResolveInfo>() { public int compare(ResolveInfo a,ResolveInfo b) { return a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()); }});
        return list;
    }
    private void launch(ResolveInfo ri) {
        try { Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER); i.setClassName(ri.activityInfo.packageName,ri.activityInfo.name); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception e) { Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show(); }
    }
    private void searchYandex(String q) {
        String query=q==null?"":q.trim(); if(query.isEmpty()) { query=""; }
        try { Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/search/?text="+Uri.encode(query))); startActivity(i); }
        catch(Exception e) { Toast.makeText(this,"Не найден браузер для открытия Яндекса",Toast.LENGTH_LONG).show(); }
    }
}
