package ru.leia.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import android.content.pm.ResolveInfo;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private boolean dark;
    private String filter = "Все";
    private int bg, surface, surface2, fg, muted, accent;
    private LinearLayout root, content;
    private List<ResolveInfo> apps;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("leia", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", isSystemDark());
        applyPalette();
        buildHome();
    }
    private boolean isSystemDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }
    private void applyPalette() {
        if (dark) {
            bg=Color.rgb(11,17,29); surface=Color.rgb(24,34,52); surface2=Color.rgb(31,45,67);
            fg=Color.rgb(242,246,253); muted=Color.rgb(160,177,199); accent=Color.rgb(105,205,244);
        } else {
            bg=Color.rgb(239,244,250); surface=Color.WHITE; surface2=Color.rgb(225,235,246);
            fg=Color.rgb(25,39,58); muted=Color.rgb(94,112,133); accent=Color.rgb(0,119,180);
        }
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, float size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private void buildHome() {
        root=col(); root.setBackgroundColor(bg); root.setPadding(dp(18),dp(12),dp(18),dp(8));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        content=col(); scroll.addView(content);
        LinearLayout top=row();
        LinearLayout clockBox=col();
        TextView clock=label(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),38,fg,true);
        TextView date=label(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),13,muted,false);
        clockBox.addView(clock); clockBox.addView(date);
        top.addView(clockBox,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=label("⚙",27,fg,false); settings.setGravity(Gravity.CENTER);
        settings.setBackground(shape(surface,18,0)); top.addView(settings, new LinearLayout.LayoutParams(dp(48),dp(48)));
        settings.setOnClickListener(v->showSettings());
        content.addView(top,lp(-1,66));

        EditText search=new EditText(this); search.setSingleLine(true); search.setTextColor(fg); search.setHintTextColor(muted);
        search.setHint("⌕   Поиск в Яндексе"); search.setTextSize(16); search.setPadding(dp(16),0,dp(16),0);
        search.setBackground(shape(surface,18,0)); search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v,a,e)->{searchYandex(search.getText().toString());return true;});
        LinearLayout.LayoutParams sp=lp(-1,54); sp.topMargin=dp(14); content.addView(search,sp);
        search.setOnClickListener(v->{search.setFocusableInTouchMode(true);search.requestFocus();});

        LinearLayout welcome=row(); welcome.setPadding(dp(16),dp(14),dp(16),dp(14));
        welcome.setBackground(shape(surface2,20,0));
        LinearLayout welcomeText=col(); welcomeText.addView(label("ТВОЁ ПРОСТРАНСТВО",10,accent,true));
        welcomeText.addView(label("Всё важное рядом.",19,fg,true));
        welcomeText.addView(label("Leia Launcher 2.0 · preview",11,muted,false));
        welcome.addView(welcomeText,new LinearLayout.LayoutParams(0,-2,1));
        welcome.addView(label("✦",30,accent,true)); LinearLayout.LayoutParams wp=lp(-1,94);wp.topMargin=dp(12);content.addView(welcome,wp);

        LinearLayout section=row(); TextView title=label("Приложения",20,fg,true);
        section.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=label("Обновить  ↻",12,accent,true); all.setOnClickListener(v->buildHome());section.addView(all);
        LinearLayout.LayoutParams secp=lp(-1,48);secp.topMargin=dp(12);content.addView(section,secp);
        LinearLayout tabs=row(); tabs.setGravity(Gravity.CENTER_VERTICAL);
        String[] filters={"Все","Избранное","Кино","Игры","Радио","Работа"};
        for(String f:filters){
            TextView chip=label(f,12,filter.equals(f)?(dark?Color.rgb(10,25,40):Color.WHITE):muted,true);
            chip.setGravity(Gravity.CENTER); chip.setPadding(dp(12),dp(8),dp(12),dp(8));
            chip.setBackground(shape(filter.equals(f)?accent:surface,18,0));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(36));cp.rightMargin=dp(6);tabs.addView(chip,cp);
            chip.setOnClickListener(v->{filter=f;buildHome();});
        }
        content.addView(tabs,lp(-1,42));
        apps=getLaunchableApps();
        Set<String> favorites=prefs.getStringSet("favorites",new HashSet<>());
        List<ResolveInfo> shown=new ArrayList<>();
        for(ResolveInfo ri:apps){
            String pkg=ri.activityInfo.packageName;
            if(filter.equals("Избранное") && !favorites.contains(pkg))continue;
            if(!filter.equals("Все")&&!filter.equals("Избранное")&&!belongs(ri,filter))continue;
            shown.add(ri);
        }
        if(shown.isEmpty()){
            TextView empty=label(filter.equals("Избранное")?"Пока нет избранных. Зажми значок приложения, чтобы добавить.":"В этой категории пока ничего нет.",13,muted,false);
            empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(28),0,dp(28));content.addView(empty);
        }
        GridLayout grid=new GridLayout(this);grid.setColumnCount(getResources().getConfiguration().orientation==2?6:4);
        for(ResolveInfo ri:shown){
            LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(3),dp(8),dp(3),dp(6));
            ImageView icon=new ImageView(this);try{icon.setImageDrawable(ri.loadIcon(getPackageManager()));}catch(Exception ignored){}
            tile.addView(icon,lp(48,48));
            TextView name=label(ri.loadLabel(getPackageManager()).toString(),11,fg,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);tile.addView(name,lp(-1,34));
            tile.setOnClickListener(v->launch(ri));
            tile.setOnLongClickListener(v->{toggleFavorite(ri);return true;});
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(94);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(tile,gp);
        }
        content.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        buildDock(root,favorites);
        setContentView(root);
    }
    private boolean belongs(ResolveInfo r,String category){
        String s=(r.loadLabel(getPackageManager()).toString()+" "+r.activityInfo.packageName).toLowerCase(Locale.ROOT);
        if(category.equals("Кино"))return has(s,"video","kino","ivi","okko","film","media","youtube","kinopoisk","плеер");
        if(category.equals("Игры"))return has(s,"game","games","playstation","xbox","steam","игр");
        if(category.equals("Радио"))return has(s,"radio","malahit","sdr","радио");
        return has(s,"office","work","docs","word","excel","mail","calendar","банк","госуслуг");
    }
    private boolean has(String s,String... keys){for(String k:keys)if(s.contains(k))return true;return false;}
    private void buildDock(LinearLayout parent,Set<String> favorites){
        LinearLayout dock=row();dock.setGravity(Gravity.CENTER);dock.setPadding(dp(8),dp(8),dp(8),dp(8));dock.setBackground(shape(surface,22,0));
        int count=0;
        for(ResolveInfo ri:apps){if(favorites.contains(ri.activityInfo.packageName)&&count<5){
            ImageView icon=new ImageView(this);try{icon.setImageDrawable(ri.loadIcon(getPackageManager()));}catch(Exception ignored){}
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(44),dp(44));ip.setMargins(dp(8),0,dp(8),0);dock.addView(icon,ip);icon.setOnClickListener(v->launch(ri));count++;
        }}
        if(count==0){TextView hint=label("Избранное появится здесь — зажми значок приложения",11,muted,false);hint.setGravity(Gravity.CENTER);dock.addView(hint);}
        LinearLayout.LayoutParams dp=lp(-1,60);dp.topMargin=dp(8);parent.addView(dock,dp);
    }
    private void toggleFavorite(ResolveInfo ri){
        Set<String> set=new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));
        String pkg=ri.activityInfo.packageName;
        if(set.contains(pkg)){set.remove(pkg);Toast.makeText(this,"Удалено из избранного",Toast.LENGTH_SHORT).show();}
        else{set.add(pkg);Toast.makeText(this,"Добавлено в избранное",Toast.LENGTH_SHORT).show();}
        prefs.edit().putStringSet("favorites",set).apply();buildHome();
    }
    private void showSettings(){
        String[] choices={"Автоматически (как в Android)","Тёмная тема","Светлая тема","Сбросить избранное"};
        new AlertDialog.Builder(this).setTitle("Настройки Leia").setItems(choices,(d,w)->{
            if(w==0){dark=isSystemDark();prefs.edit().remove("dark").apply();}
            if(w==1||w==2){dark=w==1;prefs.edit().putBoolean("dark",dark).apply();}
            if(w==3){prefs.edit().remove("favorites").apply();}
            applyPalette();buildHome();
        }).setNegativeButton("Закрыть",null).show();
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private List<ResolveInfo> getLaunchableApps(){
        Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list=getPackageManager().queryIntentActivities(i,0);
        Collections.sort(list,new Comparator<ResolveInfo>(){public int compare(ResolveInfo a,ResolveInfo b){return a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString());}});
        return list;
    }
    private void launch(ResolveInfo r){try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setClassName(r.activityInfo.packageName,r.activityInfo.name);startActivity(i);}catch(Exception e){Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show();}}
    private void searchYandex(String q){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://yandex.ru/search/?text="+Uri.encode(q==null?"":q.trim()))));}catch(Exception e){Toast.makeText(this,"Не найден браузер",Toast.LENGTH_LONG).show();}}
}
