# Leia Launcher 2.0 preview

Android launcher prototype for DOOGEE T30Pro / Android 13.

Features in this preview:
- adaptive 4-column portrait / 6-column landscape app grid;
- Yandex search field;
- system-following, light, and dark appearance choices;
- favorites via long-press on an app icon;
- favorites dock (up to five apps);
- simple name/package-based category filters: Cinema, Games, Radio, Work;
- favorites and theme preference stored locally.

Limitations:
- category matching is heuristic and may not classify every app correctly;
- no drag-and-drop, editable folders, live weather/calendar/music widgets yet;
- theme follows system only after reopening/rebuilding the launcher, not a live configuration listener;
- not runtime-tested on physical DOOGEE T30Pro. Keep stock launcher available until verified.

Build: JDK 17, Android SDK 35, Gradle 8.7.
