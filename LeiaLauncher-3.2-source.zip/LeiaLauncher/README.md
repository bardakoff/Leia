# Leia Launcher 3.2

Android tablet launcher for DOOGEE T30Pro / Android 13.

Changes in 3.1:
- brighter default palette and soft gradient background;
- custom wallpaper selection from the device gallery (persistent URI permission);
- weather card opens an installed weather app or Yandex weather search;
- music card opens an installed music app or Yandex Music;
- cache installed app list and icon constant states to reduce repeated package/icon loading while switching categories;
- horizontal scrolling category chips;
- clearer empty states for categories and favorites.

Changes in 3.2:
- refresh the clock and calendar date automatically while the launcher is visible.
- search installed apps by name or package from the home screen; send unmatched queries to Yandex.

Build: `gradle --no-daemon assembleDebug`
