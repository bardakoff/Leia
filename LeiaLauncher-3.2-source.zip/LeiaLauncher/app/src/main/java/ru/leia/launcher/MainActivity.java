package ru.leia.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.ResolveInfo;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 41;
    private SharedPreferences prefs;
    private boolean dark;
    private String filter = "Все";
    private int surface, surface2, fg, muted, accent;
    private LinearLayout root, content;
    private FrameLayout frame;
    private TextView dateView, clockView, dayView, monthView;
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockTicker = new Runnable() {
        @Override public void run() {
            updateDateTime();
            long delay = 60_000L - (System.currentTimeMillis() % 60_000L);
            clockHandler.postDelayed(this, delay);
        }
    };
    private List<ResolveInfo> apps = new ArrayList<>();
    private final Map<String, Drawable.ConstantState> iconCache = new HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("leia", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", false);
        apps = getLaunchableApps();
        applyPalette(); buildHome();
    }
    @Override protected void onStart() {
        super.onStart();
        clockHandler.removeCallbacks(clockTicker);
        clockTicker.run();
    }
    @Override protected void onStop() {
        clockHandler.removeCallbacks(clockTicker);
        super.onStop();
    }
    private void updateDateTime() {
        Date now = new Date();
        if (dateView != null) dateView.setText(new SimpleDateFormat("EEEE, d MMMM", new Locale("ru")).format(now));
        if (clockView != null) clockView.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        if (dayView != null) dayView.setText(new SimpleDateFormat("d", Locale.getDefault()).format(now));
        if (monthView != null) monthView.setText(new SimpleDateFormat("MMM", Locale.getDefault()).format(now).toUpperCase(new Locale("ru")));
    }
    private boolean isSystemDark() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }
    private void applyPalette() {
        if (dark) {
            surface=0xE6293B55; surface2=0xD9364B68; fg=Color.WHITE;
            muted=0xFFE0E8F2; accent=0xFF9BD4FF;
        } else {
            surface=0xDDFBFDFF; surface2=0xDDEAF3FC; fg=0xFF172B45;
            muted=0xFF526982; accent=0xFF176DB5;
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | (dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR));
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, float size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}

    private void buildHome() {
        frame = new FrameLayout(this);
        frame.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFB9D9F3,0xFFE7DFF2,0xFFF5E9D9}));
        String wallpaper = prefs.getString("wallpaper", "");
        if (!wallpaper.isEmpty()) {
            try { ImageView image = new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setImageURI(Uri.parse(wallpaper));
                frame.addView(image,new FrameLayout.LayoutParams(-1,-1)); } catch(Exception ignored) {}
        }
        root=col(); root.setPadding(dp(22),dp(34),dp(22),dp(10));
        root.setBackgroundColor(Color.TRANSPARENT);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        content=col(); scroll.addView(content);

        LinearLayout status=row();
        dateView=label(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),13,fg,true);
        status.addView(dateView,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=label("⚙",22,fg,false); settings.setGravity(Gravity.CENTER);
        settings.setBackground(shape(surface,18,0)); status.addView(settings,lp(44,44));
        settings.setOnClickListener(v->showSettings()); content.addView(status,lp(-1,48));

        LinearLayout hero=row(); hero.setGravity(Gravity.CENTER_VERTICAL); hero.setPadding(dp(20),dp(14),dp(20),dp(14));
        hero.setBackground(shape(surface,26,0));
        LinearLayout time=col();
        clockView=label(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),48,fg,true);
        time.addView(clockView); time.addView(label("ТВОЁ ПРОСТРАНСТВО",10,accent,true));
        hero.addView(time,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=col(); right.setGravity(Gravity.END);
        dayView=label(new SimpleDateFormat("d",Locale.getDefault()).format(new Date()),34,fg,true); dayView.setGravity(Gravity.RIGHT);
        right.addView(dayView); monthView=label(new SimpleDateFormat("MMM",Locale.getDefault()).format(new Date()).toUpperCase(new Locale("ru")),12,muted,true); right.addView(monthView);
        hero.addView(right); LinearLayout.LayoutParams hp=lp(-1,112);hp.topMargin=dp(12);content.addView(hero,hp);

        LinearLayout widgets=row(); widgets.setGravity(Gravity.TOP);
        LinearLayout weather=widgetCard("ПОГОДА","Открыть прогноз","☀");
        LinearLayout music=widgetCard("МУЗЫКА","Открыть плеер","♫");
        LinearLayout.LayoutParams w1=new LinearLayout.LayoutParams(0,dp(104),1);w1.rightMargin=dp(8);
        LinearLayout.LayoutParams w2=new LinearLayout.LayoutParams(0,dp(104),1);w2.leftMargin=dp(8);
        widgets.addView(weather,w1);widgets.addView(music,w2);
        LinearLayout.LayoutParams wlp=lp(-1,104);wlp.topMargin=dp(12);content.addView(widgets,wlp);

        LinearLayout searchBox=row(); searchBox.setPadding(dp(15),0,dp(14),0); searchBox.setBackground(shape(surface,18,0));
        TextView glass=label("⌕",24,muted,false);searchBox.addView(glass);
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(fg);search.setHintTextColor(muted);
        search.setHint("Найти приложение или искать в Яндексе");search.setTextSize(14);search.setPadding(dp(8),0,0,0);
        search.setBackgroundColor(Color.TRANSPARENT);search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v,a,e)->{String q=search.getText().toString().trim();if(!q.isEmpty())searchAppsOrWeb(q);return true;});
        searchBox.addView(search,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams slp=lp(-1,52);slp.topMargin=dp(14);content.addView(searchBox,slp);

        LinearLayout section=row(); TextView title=label("Приложения",21,fg,true);
        section.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView all=label("Все  ›",13,accent,true);all.setOnClickListener(v->{filter="Все";buildHome();});section.addView(all);
        LinearLayout.LayoutParams secp=lp(-1,48);secp.topMargin=dp(12);content.addView(section,secp);

        LinearLayout tabs=row();String[] filters={"Все","Избранное","Кино","Игры","Радио","Работа"};
        for(String f:filters){TextView chip=label(f,12,filter.equals(f)?(dark?0xFF10263C:Color.WHITE):fg,true);
            chip.setGravity(Gravity.CENTER);chip.setPadding(dp(13),dp(8),dp(13),dp(8));chip.setBackground(shape(filter.equals(f)?accent:surface,18,0));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(34));cp.rightMargin=dp(7);tabs.addView(chip,cp);chip.setOnClickListener(v->{filter=f;buildHome();});}
        HorizontalScrollView tabScroll=new HorizontalScrollView(this);tabScroll.setHorizontalScrollBarEnabled(false);tabScroll.setFillViewport(false);tabScroll.addView(tabs);
        content.addView(tabScroll,lp(-1,38));

        Set<String> favorites=prefs.getStringSet("favorites",new HashSet<>());List<ResolveInfo> shown=new ArrayList<>();
        for(ResolveInfo ri:apps){String pkg=ri.activityInfo.packageName;
            if(filter.equals("Избранное")&&!favorites.contains(pkg))continue;
            if(!filter.equals("Все")&&!filter.equals("Избранное")&&!belongs(ri,filter))continue;shown.add(ri);}
        if(shown.isEmpty()){TextView empty=label(filter.equals("Избранное")?"Удерживай иконку приложения, чтобы добавить его сюда.":"В этой категории пока ничего не найдено.",13,muted,false);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(24),0,dp(24));content.addView(empty);}
        android.widget.GridLayout grid=new android.widget.GridLayout(this);int cols=getResources().getConfiguration().orientation==2?7:5;grid.setColumnCount(cols);
        for(ResolveInfo ri:shown){LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(2),dp(8),dp(2),dp(4));
            ImageView icon=new ImageView(this);icon.setImageDrawable(cachedIcon(ri));
            tile.addView(icon,lp(52,52));TextView name=label(ri.loadLabel(getPackageManager()).toString(),11,fg,false);name.setGravity(Gravity.CENTER);name.setMaxLines(2);tile.addView(name,lp(-1,34));
            tile.setOnClickListener(v->launch(ri));tile.setOnLongClickListener(v->{toggleFavorite(ri);return true;});
            android.widget.GridLayout.LayoutParams gp=new android.widget.GridLayout.LayoutParams();gp.width=0;gp.height=dp(100);gp.columnSpec=android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED,1f);gp.setMargins(dp(3),dp(2),dp(3),dp(2));grid.addView(tile,gp);}
        content.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));buildDock(root,favorites);
        frame.addView(root,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);
    }
    private Drawable cachedIcon(ResolveInfo ri) {
        String key=ri.activityInfo.packageName;
        try { Drawable.ConstantState state=iconCache.get(key); if(state!=null)return state.newDrawable(getResources());
            Drawable d=ri.loadIcon(getPackageManager()); if(d.getConstantState()!=null)iconCache.put(key,d.getConstantState()); return d;
        } catch(Exception e){return getDrawable(android.R.drawable.sym_def_app_icon);}
    }
    private LinearLayout widgetCard(String heading,String body,String glyph){
        LinearLayout card=col();card.setPadding(dp(14),dp(12),dp(12),dp(10));card.setBackground(shape(surface2,22,0));
        LinearLayout top=row();top.addView(label(heading,9,accent,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(label(glyph,21,accent,true));card.addView(top);
        TextView b=label(body,12,fg,false);b.setMaxLines(2);LinearLayout.LayoutParams bp=lp(-1,-2);bp.topMargin=dp(12);card.addView(b,bp);
        card.setClickable(true); card.setOnClickListener(v->{if(heading.equals("ПОГОДА"))openWeather();else openMusic();}); return card;
    }
    private void openWeather(){
        if(!launchMatching(new String[]{"погода","weather","яндекс погода"}))searchYandex("погода сегодня");
    }
    private void openMusic(){
        if(!launchMatching(new String[]{"яндекс музыка","spotify","музыка","music"})){
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://music.yandex.ru")));}catch(Exception e){Toast.makeText(this,"Не найден музыкальный плеер",Toast.LENGTH_SHORT).show();}
        }
    }
    private boolean launchMatching(String[] names){
        for(ResolveInfo ri:apps){String n=ri.loadLabel(getPackageManager()).toString().toLowerCase(new Locale("ru"));
            for(String q:names)if(n.contains(q)){launch(ri);return true;}}
        return false;
    }
    private boolean belongs(ResolveInfo r,String category){String s=(r.loadLabel(getPackageManager()).toString()+" "+r.activityInfo.packageName).toLowerCase(Locale.ROOT);
        if(category.equals("Кино"))return has(s,"video","kino","ivi","okko","film","media","youtube","kinopoisk","плеер","кино","видео");
        if(category.equals("Игры"))return has(s,"game","games","playstation","xbox","steam","игр");
        if(category.equals("Радио"))return has(s,"radio","malahit","sdr","радио");
        return has(s,"office","work","docs","word","excel","mail","calendar","банк","госуслуг","почта","документ");}
    private boolean has(String s,String...keys){for(String k:keys)if(s.contains(k))return true;return false;}
    private void buildDock(LinearLayout parent,Set<String> favorites){
        LinearLayout dock=row();dock.setGravity(Gravity.CENTER);dock.setPadding(dp(10),dp(8),dp(10),dp(8));dock.setBackground(shape(surface,24,0));int count=0;
        for(ResolveInfo ri:apps){if(favorites.contains(ri.activityInfo.packageName)&&count<6){ImageView icon=new ImageView(this);icon.setImageDrawable(cachedIcon(ri));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(46),dp(46));ip.setMargins(dp(7),0,dp(7),0);dock.addView(icon,ip);icon.setOnClickListener(v->launch(ri));count++;}}
        if(count==0){TextView hint=label("Избранное · удерживай иконку, чтобы добавить",11,muted,false);hint.setGravity(Gravity.CENTER);dock.addView(hint);}
        LinearLayout.LayoutParams dpLp=lp(-1,62);dpLp.topMargin=dp(8);parent.addView(dock,dpLp);
    }
    private void toggleFavorite(ResolveInfo ri){Set<String> set=new HashSet<>(prefs.getStringSet("favorites",new HashSet<>()));String pkg=ri.activityInfo.packageName;
        if(set.contains(pkg)){set.remove(pkg);Toast.makeText(this,"Удалено из избранного",Toast.LENGTH_SHORT).show();}else{set.add(pkg);Toast.makeText(this,"Добавлено в Dock",Toast.LENGTH_SHORT).show();}
        prefs.edit().putStringSet("favorites",set).apply();buildHome();}
    private void showSettings(){String[] choices={"Выбрать обои из галереи","Убрать обои","Светлая тема","Тёмная тема","Автоматическая тема","Сбросить избранное"};
        new AlertDialog.Builder(this).setTitle("Настройки Leia").setItems(choices,(d,w)->{
            if(w==0){Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");startActivityForResult(pick,PICK_WALLPAPER);return;}
            if(w==1)prefs.edit().remove("wallpaper").apply();
            if(w==2){dark=false;prefs.edit().putBoolean("dark",false).apply();}
            if(w==3){dark=true;prefs.edit().putBoolean("dark",true).apply();}
            if(w==4){dark=isSystemDark();prefs.edit().remove("dark").apply();}
            if(w==5)prefs.edit().remove("favorites").apply();
            applyPalette();buildHome();}).setNegativeButton("Закрыть",null).show();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_WALLPAPER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION));prefs.edit().putString("wallpaper",uri.toString()).apply();}catch(Exception e){Toast.makeText(this,"Не удалось сохранить доступ к обоям",Toast.LENGTH_SHORT).show();}buildHome();}}
    private List<ResolveInfo> getLaunchableApps(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=getPackageManager().queryIntentActivities(i,0);
        Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));return list;}
    private void launch(ResolveInfo r){try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setClassName(r.activityInfo.packageName,r.activityInfo.name);startActivity(i);}catch(Exception e){Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show();}}
    private void searchAppsOrWeb(String query){
        String term=query.toLowerCase(new Locale("ru"));
        List<ResolveInfo> matches=new ArrayList<>();
        List<String> labels=new ArrayList<>();
        for(ResolveInfo ri:apps){
            String appLabel=ri.loadLabel(getPackageManager()).toString();
            String searchable=(appLabel+" "+ri.activityInfo.packageName).toLowerCase(new Locale("ru"));
            if(searchable.contains(term)){matches.add(ri);labels.add(appLabel);}
        }
        if(matches.isEmpty()){searchYandex(query);return;}
        if(matches.size()==1){launch(matches.get(0));return;}
        new AlertDialog.Builder(this).setTitle("Найденные приложения")
                .setItems(labels.toArray(new String[0]),(dialog,which)->launch(matches.get(which)))
                .setNegativeButton("Искать в Яндексе",(dialog,which)->searchYandex(query)).show();
    }
    private void searchYandex(String q){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://yandex.ru/search/?text="+Uri.encode(q==null?"":q.trim()))));}catch(Exception e){Toast.makeText(this,"Не найден браузер",Toast.LENGTH_LONG).show();}}
}
