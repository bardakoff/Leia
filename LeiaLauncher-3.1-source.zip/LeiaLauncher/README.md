# Leia Launcher 3.1

Android tablet launcher for DOOGEE T30Pro / Android 13.

Changes in 3.1:
- brighter default palette and soft gradient background;
- custom wallpaper selection from the device gallery (persistent URI permission);
- weather card opens an installed weather app or Yandex weather search;
- music card opens an installed music app or Yandex Music;
- cache installed app list and icon constant states to reduce repeated package/icon loading while switching categories;
- horizontal scrolling category chips;
- clearer empty states for categories and favorites.

Build: `gradle --no-daemon assembleDebug`
